"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AppModule = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const typeorm_1 = require("@nestjs/typeorm");
const auth_module_1 = require("./auth/auth.module");
const equipements_module_1 = require("./equipements/equipements.module");
const coherence_module_1 = require("./coherence/coherence.module");
const historique_module_1 = require("./historique/historique.module");
const niveaux_module_1 = require("./niveaux/niveaux.module");
const public_module_1 = require("./public/public.module");
const evaluations_module_1 = require("./evaluations/evaluations.module");
const configurateur_module_1 = require("./configurateur/configurateur.module");
const evaluation_entity_1 = require("./evaluations/evaluation.entity");
const user_entity_1 = require("./users/user.entity");
const equipement_entity_1 = require("./equipements/equipement.entity");
const specialite_entity_1 = require("./equipements/specialite.entity");
const sous_referentiel_entity_1 = require("./equipements/sous-referentiel.entity");
const usage_entity_1 = require("./equipements/usage.entity");
const service_entity_1 = require("./equipements/service.entity");
const historique_entity_1 = require("./historique/historique.entity");
let AppModule = class AppModule {
};
exports.AppModule = AppModule;
exports.AppModule = AppModule = __decorate([
    (0, common_1.Module)({
        imports: [
            config_1.ConfigModule.forRoot({ isGlobal: true }),
            typeorm_1.TypeOrmModule.forRoot({
                type: 'mysql',
                host: process.env.DB_HOST || 'localhost',
                port: +(process.env.DB_PORT || 3306),
                username: process.env.DB_USER || 'root',
                password: process.env.DB_PASSWORD || '',
                database: process.env.DB_NAME || 'rnes',
                entities: [user_entity_1.User, equipement_entity_1.Equipement, specialite_entity_1.Specialite, sous_referentiel_entity_1.SousReferentiel, usage_entity_1.Usage, service_entity_1.Service, historique_entity_1.Historique, evaluation_entity_1.Evaluation],
                synchronize: false,
            }),
            auth_module_1.AuthModule,
            equipements_module_1.EquipementsModule,
            coherence_module_1.CoherenceModule,
            historique_module_1.HistoriqueModule,
            niveaux_module_1.NiveauxModule,
            evaluations_module_1.EvaluationsModule,
            configurateur_module_1.ConfigurateurModule,
            public_module_1.PublicModule,
        ],
    })
], AppModule);
//# sourceMappingURL=app.module.js.map