"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PublicService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const equipement_entity_1 = require("../equipements/equipement.entity");
const usage_entity_1 = require("../equipements/usage.entity");
const specialite_entity_1 = require("../equipements/specialite.entity");
const sous_referentiel_entity_1 = require("../equipements/sous-referentiel.entity");
const visibilite_1 = require("../equipements/visibilite");
let PublicService = class PublicService {
    equipements;
    usages;
    specialites;
    sousRefs;
    constructor(equipements, usages, specialites, sousRefs) {
        this.equipements = equipements;
        this.usages = usages;
        this.specialites = specialites;
        this.sousRefs = sousRefs;
    }
    async specialitesActives() {
        const rows = await this.specialites
            .createQueryBuilder('s')
            .where('s.archive = 0')
            .andWhere((0, visibilite_1.referenceValidee)('s'))
            .select('s.code_prefixe', 'code_prefixe')
            .getRawMany();
        return rows.map((s) => s.code_prefixe);
    }
    onlyVisible(qb) {
        return (0, visibilite_1.onlyVisible)(qb, 'e');
    }
    async findAllEquipements(page, limit, search, nature) {
        const currentPage = Math.max(1, page || 1);
        const perPage = Math.min(100, Math.max(1, limit || 20));
        const qb = this.onlyVisible(this.equipements.createQueryBuilder('e'));
        if (search) {
            qb.andWhere('(e.code LIKE :q OR e.designation LIKE :q)', { q: `%${search}%` });
        }
        if (nature) {
            qb.andWhere('e.nature = :nature', { nature });
        }
        const [rows, total] = await qb
            .orderBy('e.code', 'ASC')
            .skip((currentPage - 1) * perPage)
            .take(perPage)
            .getManyAndCount();
        const actives = new Set(await this.specialitesActives());
        const data = await Promise.all(rows.map((e) => this.formater(e, actives)));
        return {
            data,
            total,
            page: currentPage,
            limit: perPage,
            totalPages: Math.ceil(total / perPage),
        };
    }
    async findTransversaux() {
        const rows = await this.onlyVisible(this.equipements.createQueryBuilder('e').where('e.nature = :nature', { nature: 'T' }))
            .orderBy('e.code', 'ASC')
            .getMany();
        const actives = new Set(await this.specialitesActives());
        return Promise.all(rows.map((e) => this.formater(e, actives)));
    }
    async findOneParCode(identifiant) {
        const numeric = Number(identifiant);
        const eq = Number.isNaN(numeric)
            ? await this.equipements.findOne({ where: { code: identifiant } })
            : await this.equipements.findOne({ where: { id: numeric } });
        if (!eq || !(await this.estVisible(eq)))
            return null;
        return this.formater(eq);
    }
    async estVisible(eq) {
        const prefixe = eq.proprietaire_prefixe;
        if (!prefixe)
            return !eq.supprime;
        if (eq.nature === 'T') {
            const sousRef = await this.sousRefs.findOne({ where: { code_prefixe: prefixe } });
            return Boolean(sousRef && !sousRef.archive && (0, visibilite_1.estValidee)(sousRef.statut));
        }
        const specialite = await this.specialites.findOne({ where: { code_prefixe: prefixe } });
        return Boolean(specialite && !specialite.archive && (0, visibilite_1.estValidee)(specialite.statut));
    }
    async getStatistics() {
        const equipements = await this.onlyVisible(this.equipements.createQueryBuilder('e')).getMany();
        const visibles = equipements.map((e) => e.code);
        const prefixes = await this.specialitesActives();
        const [totalSpecialites, totalSousReferentiels, totalUsages] = await Promise.all([
            this.specialites
                .createQueryBuilder('s')
                .where('s.archive = 0')
                .andWhere((0, visibilite_1.referenceValidee)('s'))
                .getCount(),
            this.sousRefs
                .createQueryBuilder('s')
                .where('s.archive = 0')
                .andWhere((0, visibilite_1.referenceValidee)('s'))
                .getCount(),
            visibles.length && prefixes.length
                ? this.usages.count({
                    where: {
                        equipement_code: (0, typeorm_2.In)(visibles),
                        specialite_prefixe: (0, typeorm_2.In)(prefixes),
                        supprime: false,
                    },
                })
                : 0,
        ]);
        const totalEquipements = equipements.length;
        const sousClasses = visibles.length && prefixes.length
            ? await this.usages
                .createQueryBuilder('u')
                .select('COUNT(DISTINCT u.sous_famille_clinique)', 'total')
                .where('u.supprime = 0')
                .andWhere('u.equipement_code IN (:...codes)', { codes: visibles })
                .andWhere('u.specialite_prefixe IN (:...prefixes)', { prefixes })
                .getRawOne()
            : null;
        const totalSousClassesCliniques = Number(sousClasses?.total ?? 0);
        const repartitionNature = { S: 0, SP: 0, T: 0 };
        for (const eq of equipements) {
            if (eq.nature === 'S')
                repartitionNature.S++;
            else if (eq.nature === 'SP')
                repartitionNature.SP++;
            else if (eq.nature === 'T')
                repartitionNature.T++;
        }
        const repartitionNiveaux = { 1: 0, 2: 0, 3: 0, 4: 0 };
        for (const eq of equipements) {
            let niveau = 1;
            const c = eq.criticite_clinique;
            if (c) {
                if (c.includes('4'))
                    niveau = 4;
                else if (c.includes('3'))
                    niveau = 3;
                else if (c.includes('2'))
                    niveau = 2;
            }
            repartitionNiveaux[niveau]++;
        }
        return {
            totalEquipements,
            totalSpecialites,
            totalNiveaux: 4,
            totalUsages,
            totalSousReferentiels,
            totalSousClassesCliniques,
            repartitionNature,
            repartitionNiveaux,
        };
    }
    async findSpecialites() {
        const rows = await this.specialites
            .createQueryBuilder('s')
            .leftJoin('equipements', 'e', 'e.proprietaire_prefixe = s.code_prefixe AND e.supprime = 0')
            .where('s.archive = 0')
            .andWhere((0, visibilite_1.referenceValidee)('s'))
            .select('s.id', 'id')
            .addSelect('s.code_prefixe', 'code')
            .addSelect('s.nom', 'nom')
            .addSelect('COUNT(e.id)', 'equipementCount')
            .addSelect('s.ordre_affichage', 'ordreAffichage')
            .groupBy('s.id')
            .addGroupBy('s.code_prefixe')
            .addGroupBy('s.nom')
            .addGroupBy('s.ordre_affichage')
            .orderBy('s.code_prefixe', 'ASC')
            .getRawMany();
        return rows.map((r) => ({
            id: String(r.id),
            code: r.code,
            nom: r.nom,
            description: '',
            equipementCount: Number(r.equipementCount),
            niveau: 4,
            niveaux: undefined,
        }));
    }
    async findSousReferentiels() {
        const rows = await this.sousRefs
            .createQueryBuilder('s')
            .where('s.archive = 0')
            .andWhere((0, visibilite_1.referenceValidee)('s'))
            .orderBy('s.ordre_affichage', 'ASC')
            .getMany();
        return rows.map((r) => ({
            id: r.id,
            codePrefixe: r.code_prefixe,
            nom: r.nom,
            description: '',
            ordreAffichage: r.ordre_affichage,
            statut: r.statut,
            archive: r.archive ? 1 : 0,
        }));
    }
    async findUsages() {
        const rows = await this.usages
            .createQueryBuilder('u')
            .where('u.supprime = 0')
            .andWhere(visibilite_1.USAGE_VISIBLE)
            .getMany();
        return rows.map((u) => ({
            id: u.id,
            equipementCode: u.equipement_code,
            specialite: u.specialite_prefixe,
            specialiteCode: u.specialite_prefixe,
            niveau1: u.nv1,
            niveau2: u.nv2,
            niveau3: u.nv3,
            niveau4: u.nv4,
            indicateurPlanification: u.indicateur_planification ?? null,
            prerequis: u.prerequis ?? null,
            caracteristiquesIndicatives: u.caracteristiques_indicatives ?? null,
            sousFamilleClinique: u.sous_famille_clinique ?? null,
        }));
    }
    async findSpecialite(id) {
        const parsed = Number(id);
        const where = Number.isNaN(parsed)
            ? { code_prefixe: id, archive: false }
            : { id: parsed, archive: false };
        const s = await this.specialites.findOne({ where: where });
        if (!s || !(0, visibilite_1.estValidee)(s.statut))
            return null;
        const equipementCount = await this.equipements.count({
            where: { proprietaire_prefixe: s.code_prefixe, supprime: false },
        });
        return {
            id: String(s.id),
            code: s.code_prefixe,
            nom: s.nom,
            description: '',
            equipementCount,
            niveau: 4,
            niveaux: undefined,
        };
    }
    async findEquipementsParSpecialite(specialiteId) {
        const specialite = await this.findSpecialite(specialiteId);
        if (!specialite)
            return [];
        const rows = await this.onlyVisible(this.equipements
            .createQueryBuilder('e')
            .leftJoin('usages', 'u', 'u.equipement_code = e.code AND u.supprime = 0')
            .andWhere('(e.proprietaire_prefixe = :prefixe OR u.specialite_prefixe = :prefixe)', { prefixe: specialite.code }))
            .select('e.id', 'id')
            .distinct(true)
            .getRawMany();
        const ids = rows.map((r) => Number(r.id));
        if (ids.length === 0)
            return [];
        const entities = await this.equipements.find({ where: { id: (0, typeorm_2.In)(ids) } });
        entities.sort((a, b) => a.code.localeCompare(b.code));
        const actives = new Set(await this.specialitesActives());
        return Promise.all(entities.map((e) => this.formater(e, actives)));
    }
    async formater(eq, activesFourni) {
        const eqUsages = await this.usages
            .createQueryBuilder('u')
            .where('u.equipement_code = :code', { code: eq.code })
            .andWhere('u.supprime = 0')
            .andWhere(`u.specialite_prefixe IN ${visibilite_1.SPECIALITES_VALIDES}`)
            .getMany();
        let niveau = 1;
        let categorie = 'CAT B';
        let sousFamilleClinique = null;
        for (const u of eqUsages) {
            if (u.nv4)
                niveau = 4;
            else if (u.nv3 && niveau < 3)
                niveau = 3;
            else if (u.nv2 && niveau < 2)
                niveau = 2;
            if (u.nv1 === 'CAT A' || u.nv2 === 'CAT A' || u.nv3 === 'CAT A' || u.nv4 === 'CAT A') {
                categorie = 'CAT A';
            }
            if (!sousFamilleClinique && u.sous_famille_clinique) {
                sousFamilleClinique = u.sous_famille_clinique;
            }
        }
        let categorieTransversale = null;
        if (eq.nature === 'T' && eq.proprietaire_prefixe) {
            const sousRef = await this.sousRefs.findOne({
                where: { code_prefixe: eq.proprietaire_prefixe, archive: false },
            });
            categorieTransversale = sousRef?.nom ?? null;
        }
        const actives = activesFourni ?? new Set(await this.specialitesActives());
        const specialiteIds = [
            ...new Set(eqUsages
                .map((u) => u.specialite_prefixe)
                .filter((p) => Boolean(p) && actives.has(p))),
        ];
        if (specialiteIds.length === 0 && eq.proprietaire_prefixe) {
            if (actives.has(eq.proprietaire_prefixe)) {
                specialiteIds.push(eq.proprietaire_prefixe);
            }
        }
        return {
            id: String(eq.id),
            code: eq.code,
            nom: eq.designation,
            nature: eq.nature,
            description: eq.justification ?? '',
            sousFamilleClinique,
            categorieTransversale,
            specialiteIds,
            niveau,
            categorie,
            statut: eq.statut,
            usages: eqUsages.map((u) => ({
                id: u.id,
                specialite: u.specialite_prefixe,
                specialiteCode: u.specialite_prefixe,
                niveau1: u.nv1,
                niveau2: u.nv2,
                niveau3: u.nv3,
                niveau4: u.nv4,
                indicateurPlanification: u.indicateur_planification ?? null,
                prerequis: u.prerequis ?? null,
                caracteristiquesIndicatives: u.caracteristiques_indicatives ?? null,
                sousFamilleClinique: u.sous_famille_clinique ?? null,
            })),
            proprietaireType: eq.proprietaire_type ?? null,
            proprietairePrefixe: eq.proprietaire_prefixe ?? null,
            typeObjet: eq.type_objet ?? null,
            familleTechnique: eq.famille_technique ?? null,
            criticiteClinique: eq.criticite_clinique ?? null,
            modeMaintenance: eq.mode_maintenance ?? null,
            modeMiseADisposition: eq.mode_mise_a_disposition ?? null,
            portee: eq.portee ?? null,
            justification: eq.justification ?? null,
            createdAt: '',
            updatedAt: '',
        };
    }
};
exports.PublicService = PublicService;
exports.PublicService = PublicService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(equipement_entity_1.Equipement)),
    __param(1, (0, typeorm_1.InjectRepository)(usage_entity_1.Usage)),
    __param(2, (0, typeorm_1.InjectRepository)(specialite_entity_1.Specialite)),
    __param(3, (0, typeorm_1.InjectRepository)(sous_referentiel_entity_1.SousReferentiel)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository])
], PublicService);
//# sourceMappingURL=public.service.js.map