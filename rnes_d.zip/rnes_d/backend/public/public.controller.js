"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PublicController = void 0;
const common_1 = require("@nestjs/common");
const public_service_1 = require("./public.service");
const public_decorator_1 = require("../auth/public.decorator");
let PublicController = class PublicController {
    publicService;
    constructor(publicService) {
        this.publicService = publicService;
    }
    findAll(page, limit, search, nature) {
        return this.publicService.findAllEquipements(parseInt(page ?? '', 10) || 1, parseInt(limit ?? '', 10) || 20, search, nature);
    }
    findTransversaux() {
        return this.publicService.findTransversaux();
    }
    stats() {
        return this.publicService.getStatistics();
    }
    async findOne(code) {
        const eq = await this.publicService.findOneParCode(code);
        if (!eq)
            throw new common_1.NotFoundException(`Équipement "${code}" introuvable`);
        return eq;
    }
    findSpecialites() {
        return this.publicService.findSpecialites();
    }
    findSousReferentiels() {
        return this.publicService.findSousReferentiels();
    }
    findUsages() {
        return this.publicService.findUsages();
    }
    statistics() {
        return this.publicService.getStatistics();
    }
    dashboardStats() {
        return this.publicService.getStatistics();
    }
    async findSpecialite(id) {
        const specialite = await this.publicService.findSpecialite(id);
        if (!specialite)
            throw new common_1.NotFoundException(`Spécialité "${id}" introuvable`);
        return specialite;
    }
    async findEquipementsParSpecialite(specialiteId) {
        return this.publicService.findEquipementsParSpecialite(specialiteId);
    }
};
exports.PublicController = PublicController;
__decorate([
    (0, common_1.Get)('equipements'),
    __param(0, (0, common_1.Query)('page')),
    __param(1, (0, common_1.Query)('limit')),
    __param(2, (0, common_1.Query)('search')),
    __param(3, (0, common_1.Query)('nature')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String]),
    __metadata("design:returntype", void 0)
], PublicController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)('equipements/transversaux'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], PublicController.prototype, "findTransversaux", null);
__decorate([
    (0, common_1.Get)('equipements/stats'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], PublicController.prototype, "stats", null);
__decorate([
    (0, common_1.Get)('equipements/:code'),
    __param(0, (0, common_1.Param)('code')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], PublicController.prototype, "findOne", null);
__decorate([
    (0, common_1.Get)('specialites'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], PublicController.prototype, "findSpecialites", null);
__decorate([
    (0, common_1.Get)('sous-referentiels'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], PublicController.prototype, "findSousReferentiels", null);
__decorate([
    (0, common_1.Get)('usages'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], PublicController.prototype, "findUsages", null);
__decorate([
    (0, common_1.Get)('statistics'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], PublicController.prototype, "statistics", null);
__decorate([
    (0, common_1.Get)('dashboard/stats'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], PublicController.prototype, "dashboardStats", null);
__decorate([
    (0, common_1.Get)('specialites/:id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], PublicController.prototype, "findSpecialite", null);
__decorate([
    (0, common_1.Get)('equipements/specialite/:specialiteId'),
    __param(0, (0, common_1.Param)('specialiteId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], PublicController.prototype, "findEquipementsParSpecialite", null);
exports.PublicController = PublicController = __decorate([
    (0, common_1.Controller)('api'),
    (0, public_decorator_1.Public)(),
    __metadata("design:paramtypes", [public_service_1.PublicService])
], PublicController);
//# sourceMappingURL=public.controller.js.map