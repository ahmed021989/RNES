"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PublicModule = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const equipement_entity_1 = require("../equipements/equipement.entity");
const usage_entity_1 = require("../equipements/usage.entity");
const specialite_entity_1 = require("../equipements/specialite.entity");
const sous_referentiel_entity_1 = require("../equipements/sous-referentiel.entity");
const public_controller_1 = require("./public.controller");
const public_service_1 = require("./public.service");
let PublicModule = class PublicModule {
};
exports.PublicModule = PublicModule;
exports.PublicModule = PublicModule = __decorate([
    (0, common_1.Module)({
        imports: [typeorm_1.TypeOrmModule.forFeature([equipement_entity_1.Equipement, usage_entity_1.Usage, specialite_entity_1.Specialite, sous_referentiel_entity_1.SousReferentiel])],
        controllers: [public_controller_1.PublicController],
        providers: [public_service_1.PublicService],
        exports: [public_service_1.PublicService],
    })
], PublicModule);
//# sourceMappingURL=public.module.js.map