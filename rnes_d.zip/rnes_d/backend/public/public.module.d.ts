export declare class PublicModule {
}
