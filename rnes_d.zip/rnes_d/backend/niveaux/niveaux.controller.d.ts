import { NiveauxService } from './niveaux.service';
export declare class NiveauxController {
    private readonly niveauxService;
    constructor(niveauxService: NiveauxService);
    findAll(includeCatB?: string): Promise<import("./niveaux.entity").Niveau[]>;
    getEquipements(niveau: string, includeCatB?: string): Promise<any[]>;
}
