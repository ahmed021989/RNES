export interface Niveau {
    id: number;
    code: string;
    nom: string;
    description: string;
    equipementsCount: number;
    specialitesCount: number;
}
