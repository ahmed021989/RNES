"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.NiveauxService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const equipement_entity_1 = require("../equipements/equipement.entity");
const usage_entity_1 = require("../equipements/usage.entity");
const specialite_entity_1 = require("../equipements/specialite.entity");
const visibilite_1 = require("../equipements/visibilite");
let NiveauxService = class NiveauxService {
    equipementRepository;
    usageRepository;
    specialiteRepository;
    constructor(equipementRepository, usageRepository, specialiteRepository) {
        this.equipementRepository = equipementRepository;
        this.usageRepository = usageRepository;
        this.specialiteRepository = specialiteRepository;
    }
    async prefixesSpecialitesValidees() {
        const rows = await this.specialiteRepository
            .createQueryBuilder('s')
            .where('s.archive = 0')
            .andWhere((0, visibilite_1.referenceValidee)('s'))
            .select('s.code_prefixe', 'code_prefixe')
            .getRawMany();
        return rows.map((r) => r.code_prefixe);
    }
    async findAll(includeCatB = false) {
        const niveaux = [
            {
                id: 1,
                code: 'NV1',
                nom: 'Niveau 1',
                description: 'Soins de base et premiers secours',
                equipementsCount: 0,
                specialitesCount: 0,
            },
            {
                id: 2,
                code: 'NV2',
                nom: 'Niveau 2',
                description: 'Soins intermédiaires et hospitalisation',
                equipementsCount: 0,
                specialitesCount: 0,
            },
            {
                id: 3,
                code: 'NV3',
                nom: 'Niveau 3',
                description: 'Soins spécialisés et techniques avancées',
                equipementsCount: 0,
                specialitesCount: 0,
            },
            {
                id: 4,
                code: 'NV4',
                nom: 'Niveau 4',
                description: 'Soins hautement spécialisés et référentiels',
                equipementsCount: 0,
                specialitesCount: 0,
            },
        ];
        const usages = await this.usageRepository.find({
            where: { supprime: false },
        });
        const visibles = new Set((await (0, visibilite_1.onlyVisibleFrom)(this.equipementRepository.createQueryBuilder('equipement'), 'equipement')
            .select('equipement.code', 'code')
            .getRawMany()).map((r) => r.code));
        const specialitesActives = new Set(await this.prefixesSpecialitesValidees());
        const usagesVisibles = usages.filter((u) => visibles.has(u.equipement_code) && specialitesActives.has(u.specialite_prefixe));
        for (const niveau of niveaux) {
            const niveauKey = `nv${niveau.id}`;
            const equipementCodes = new Set(usagesVisibles
                .filter((usage) => includeCatB
                ? (usage[niveauKey] === 'CAT A' || usage[niveauKey] === 'CAT B')
                : usage[niveauKey] === 'CAT A')
                .map((usage) => usage.equipement_code));
            niveau.equipementsCount = equipementCodes.size;
        }
        const specialitesCount = await this.specialiteRepository
            .createQueryBuilder('s')
            .where('s.archive = 0')
            .andWhere((0, visibilite_1.referenceValidee)('s'))
            .getCount();
        for (const niveau of niveaux) {
            niveau.specialitesCount = specialitesCount;
        }
        return niveaux;
    }
    async getEquipements(niveau, includeCatB = false) {
        const niveauKey = `nv${niveau}`;
        const usages = await this.usageRepository.find({
            where: { supprime: false },
        });
        const equipementCodes = usages
            .filter((usage) => includeCatB
            ? (usage[niveauKey] === 'CAT A' || usage[niveauKey] === 'CAT B')
            : usage[niveauKey] === 'CAT A')
            .map((usage) => usage.equipement_code);
        if (equipementCodes.length === 0) {
            return [];
        }
        const equipements = await (0, visibilite_1.onlyVisible)(this.equipementRepository
            .createQueryBuilder('equipement')
            .where('equipement.code IN (:...codes)', { codes: equipementCodes }), 'equipement').orderBy('equipement.code', 'ASC').getMany();
        const codesVisibles = equipements.map((e) => e.code);
        const specialitesActives = new Set(await this.prefixesSpecialitesValidees());
        const usagesVisibles = usages.filter((u) => codesVisibles.includes(u.equipement_code) && specialitesActives.has(u.specialite_prefixe));
        const usagesParCode = new Map();
        for (const usage of usagesVisibles) {
            const liste = usagesParCode.get(usage.equipement_code) ?? [];
            liste.push(usage);
            usagesParCode.set(usage.equipement_code, liste);
        }
        return equipements.map((eq) => {
            const eqUsages = usagesParCode.get(eq.code) ?? [];
            return this.formater(eq, eqUsages, specialitesActives);
        });
    }
    formater(eq, usages, specialitesActives) {
        let niveau = 1;
        let categorie = 'CAT B';
        let sousFamilleClinique = null;
        for (const u of usages) {
            if (u.nv4)
                niveau = 4;
            else if (u.nv3 && niveau < 3)
                niveau = 3;
            else if (u.nv2 && niveau < 2)
                niveau = 2;
            if (u.nv1 === 'CAT A' || u.nv2 === 'CAT A' || u.nv3 === 'CAT A' || u.nv4 === 'CAT A') {
                categorie = 'CAT A';
            }
            if (!sousFamilleClinique && u.sous_famille_clinique) {
                sousFamilleClinique = u.sous_famille_clinique;
            }
        }
        return {
            id: String(eq.id),
            code: eq.code,
            nom: eq.designation,
            nature: eq.nature,
            description: eq.justification ?? '',
            sousFamilleClinique,
            categorieTransversale: null,
            specialiteIds: eq.proprietaire_prefixe && specialitesActives.has(eq.proprietaire_prefixe)
                ? [eq.proprietaire_prefixe]
                : [],
            niveau,
            categorie,
            statut: eq.statut,
            usages: usages.map((u) => ({
                id: String(u.id),
                specialite: u.specialite_prefixe,
                specialiteCode: u.specialite_prefixe,
                niveau1: u.nv1,
                niveau2: u.nv2,
                niveau3: u.nv3,
                niveau4: u.nv4,
                indicateurPlanification: u.indicateur_planification ?? null,
                prerequis: u.prerequis ?? null,
                caracteristiquesIndicatives: u.caracteristiques_indicatives ?? null,
                sousFamilleClinique: u.sous_famille_clinique ?? null,
            })),
            proprietaireType: eq.proprietaire_type ?? null,
            proprietairePrefixe: eq.proprietaire_prefixe ?? null,
            typeObjet: eq.type_objet ?? null,
            familleTechnique: eq.famille_technique ?? null,
            criticiteClinique: eq.criticite_clinique ?? null,
            modeMaintenance: eq.mode_maintenance ?? null,
            modeMiseADisposition: eq.mode_mise_a_disposition ?? null,
            portee: eq.portee ?? null,
            justification: eq.justification ?? null,
            createdAt: '',
            updatedAt: '',
        };
    }
};
exports.NiveauxService = NiveauxService;
exports.NiveauxService = NiveauxService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(equipement_entity_1.Equipement)),
    __param(1, (0, typeorm_1.InjectRepository)(usage_entity_1.Usage)),
    __param(2, (0, typeorm_1.InjectRepository)(specialite_entity_1.Specialite)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository])
], NiveauxService);
//# sourceMappingURL=niveaux.service.js.map