"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.NiveauxController = void 0;
const common_1 = require("@nestjs/common");
const niveaux_service_1 = require("./niveaux.service");
const public_decorator_1 = require("../auth/public.decorator");
let NiveauxController = class NiveauxController {
    niveauxService;
    constructor(niveauxService) {
        this.niveauxService = niveauxService;
    }
    findAll(includeCatB) {
        return this.niveauxService.findAll(includeCatB === 'true');
    }
    getEquipements(niveau, includeCatB) {
        return this.niveauxService.getEquipements(parseInt(niveau, 10), includeCatB === 'true');
    }
};
exports.NiveauxController = NiveauxController;
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, common_1.Query)('includeCatB')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], NiveauxController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)(':niveau/equipements'),
    __param(0, (0, common_1.Param)('niveau')),
    __param(1, (0, common_1.Query)('includeCatB')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", void 0)
], NiveauxController.prototype, "getEquipements", null);
exports.NiveauxController = NiveauxController = __decorate([
    (0, common_1.Controller)('api/niveaux'),
    (0, public_decorator_1.Public)(),
    __metadata("design:paramtypes", [niveaux_service_1.NiveauxService])
], NiveauxController);
//# sourceMappingURL=niveaux.controller.js.map