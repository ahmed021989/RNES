export declare class NiveauxModule {
}
