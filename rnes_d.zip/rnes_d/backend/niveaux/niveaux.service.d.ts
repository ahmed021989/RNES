import { Repository } from 'typeorm';
import { Equipement } from '../equipements/equipement.entity';
import { Usage } from '../equipements/usage.entity';
import { Specialite } from '../equipements/specialite.entity';
import { Niveau } from './niveaux.entity';
export declare class NiveauxService {
    private readonly equipementRepository;
    private readonly usageRepository;
    private readonly specialiteRepository;
    constructor(equipementRepository: Repository<Equipement>, usageRepository: Repository<Usage>, specialiteRepository: Repository<Specialite>);
    private prefixesSpecialitesValidees;
    findAll(includeCatB?: boolean): Promise<Niveau[]>;
    getEquipements(niveau: number, includeCatB?: boolean): Promise<any[]>;
    private formater;
}
