"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConfigurateurService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const equipement_entity_1 = require("../equipements/equipement.entity");
const usage_entity_1 = require("../equipements/usage.entity");
const visibilite_1 = require("../equipements/visibilite");
let ConfigurateurService = class ConfigurateurService {
    equipementRepository;
    usageRepository;
    constructor(equipementRepository, usageRepository) {
        this.equipementRepository = equipementRepository;
        this.usageRepository = usageRepository;
    }
    async generate(niveau, specialites) {
        const niveauKey = `nv${niveau}`;
        const queryBuilder = this.usageRepository
            .createQueryBuilder('usage')
            .where('usage.supprime = :supprime', { supprime: false })
            .andWhere(`usage.${niveauKey} IS NOT NULL`)
            .andWhere(`usage.specialite_prefixe IN ${visibilite_1.SPECIALITES_VALIDES}`);
        if (specialites && specialites.length > 0) {
            queryBuilder.andWhere('usage.specialite_prefixe IN (:...specialites)', {
                specialites,
            });
        }
        const usages = await queryBuilder.getMany();
        const equipementCodes = [
            ...new Set(usages.map((usage) => usage.equipement_code)),
        ];
        if (equipementCodes.length === 0) {
            return [];
        }
        return (0, visibilite_1.onlyVisible)(this.equipementRepository
            .createQueryBuilder('equipement')
            .where('equipement.code IN (:...codes)', { codes: equipementCodes }), 'equipement')
            .orderBy('equipement.code', 'ASC')
            .getMany();
    }
};
exports.ConfigurateurService = ConfigurateurService;
exports.ConfigurateurService = ConfigurateurService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(equipement_entity_1.Equipement)),
    __param(1, (0, typeorm_1.InjectRepository)(usage_entity_1.Usage)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository])
], ConfigurateurService);
//# sourceMappingURL=configurateur.service.js.map