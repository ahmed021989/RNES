import { Repository } from 'typeorm';
import { Equipement } from '../equipements/equipement.entity';
import { Usage } from '../equipements/usage.entity';
export declare class ConfigurateurService {
    private readonly equipementRepository;
    private readonly usageRepository;
    constructor(equipementRepository: Repository<Equipement>, usageRepository: Repository<Usage>);
    generate(niveau: number, specialites: string[]): Promise<Equipement[]>;
}
