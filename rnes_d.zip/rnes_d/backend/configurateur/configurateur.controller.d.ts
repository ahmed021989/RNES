import { ConfigurateurService } from './configurateur.service';
export declare class ConfigurateurController {
    private readonly configurateurService;
    constructor(configurateurService: ConfigurateurService);
    generate(body: {
        niveau: number;
        specialites: string[];
    }): Promise<import("../equipements/equipement.entity").Equipement[]>;
}
