export declare class ConfigurateurModule {
}
