"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PASSWORD_RULES = exports.PASSWORD_MIN_LENGTH = exports.PASSWORD_MAX_BYTES = void 0;
exports.findPasswordIssues = findPasswordIssues;
exports.findPasswordIssuesForUser = findPasswordIssuesForUser;
exports.MaxLengthBytes = MaxLengthBytes;
exports.IsStrongPassword = IsStrongPassword;
const class_validator_1 = require("class-validator");
exports.PASSWORD_MAX_BYTES = 72;
exports.PASSWORD_MIN_LENGTH = 8;
exports.PASSWORD_RULES = [
    {
        id: 'longueur',
        label: `Au moins ${exports.PASSWORD_MIN_LENGTH} caractères`,
        test: (p) => [...p].length >= exports.PASSWORD_MIN_LENGTH,
    },
    { id: 'majuscule', label: 'Une lettre majuscule (A-Z)', test: (p) => /[A-Z]/.test(p) },
    { id: 'minuscule', label: 'Une lettre minuscule (a-z)', test: (p) => /[a-z]/.test(p) },
    { id: 'chiffre', label: 'Un chiffre (0-9)', test: (p) => /[0-9]/.test(p) },
    { id: 'special', label: 'Un caractère spécial (!@#$%&*…)', test: (p) => /[^A-Za-z0-9]/.test(p) },
    { id: 'espace', label: 'Aucun espace', test: (p) => !/\s/.test(p) },
];
const COMMUN = new Set([
    'motdepasse', 'password', 'passwd', 'admin', 'administrateur', 'utilisateur',
    'azerty', 'qwerty', 'azertyuiop', 'rnes', 'referentiel', 'secret',
    'abc', 'xyz', 'test', 'demo', 'essai', 'passe',
    '123', '1234', '12345', '123456', '1234567', '12345678', '123456789',
    '000000', '111111', '654321', 'qwertyuiop', 'motdepasse', 'changeme',
    'bienvenue', 'welcome', 'soleil', 'football', 'baseball', 'dragon',
]);
function estCommun(password) {
    const lower = password.toLowerCase();
    if (COMMUN.has(lower))
        return true;
    for (const mot of lower.match(/[a-z]{3,}/g) ?? []) {
        if (COMMUN.has(mot))
            return true;
    }
    return false;
}
function findPasswordIssues(password) {
    if (typeof password !== 'string' || password.length === 0)
        return [];
    const issues = exports.PASSWORD_RULES.filter((r) => !r.test(password)).map((r) => r.label);
    const lower = password.toLowerCase();
    if (estCommun(password))
        issues.push('Ce mot de passe est trop courant');
    if (lower.includes('rnes'))
        issues.push('Évitez d\'y mettre le nom de l\'application');
    if (Buffer.byteLength(password, 'utf8') > exports.PASSWORD_MAX_BYTES) {
        issues.push(`Au plus ${exports.PASSWORD_MAX_BYTES} octets (les accents comptent double)`);
    }
    if (/(.)\1{3,}/.test(password)) {
        issues.push('Évitez les caractères répétés');
    }
    return issues;
}
function findPasswordIssuesForUser(password, user) {
    const issues = findPasswordIssues(password);
    const lower = password.toLowerCase();
    const localPart = user.email.split('@')[0];
    for (const fragment of [localPart, user.nom]) {
        const frag = (fragment || '').toLowerCase().trim();
        if (frag.length >= 4 && lower.includes(frag)) {
            issues.push('Le mot de passe ne doit pas contenir votre nom ou votre identifiant');
            break;
        }
    }
    return issues;
}
function MaxLengthBytes(max, validationOptions) {
    return function (object, propertyName) {
        (0, class_validator_1.registerDecorator)({
            name: 'maxLengthBytes',
            target: object.constructor,
            propertyName,
            constraints: [max],
            options: validationOptions,
            validator: {
                validate(value) {
                    return typeof value !== 'string' || Buffer.byteLength(value, 'utf8') <= max;
                },
                defaultMessage(args) {
                    return `Ce champ ne doit pas dépasser ${args.constraints[0]} octets`;
                },
            },
        });
    };
}
function IsStrongPassword(validationOptions) {
    return function (object, propertyName) {
        (0, class_validator_1.registerDecorator)({
            name: 'isStrongPassword',
            target: object.constructor,
            propertyName,
            options: validationOptions,
            validator: {
                validate(value) {
                    return typeof value === 'string' && findPasswordIssues(value).length === 0;
                },
                defaultMessage(args) {
                    const issues = findPasswordIssues(args.value);
                    return issues.length ? issues.join(' · ') : 'Mot de passe trop faible';
                },
            },
        });
    };
}
//# sourceMappingURL=password-policy.js.map