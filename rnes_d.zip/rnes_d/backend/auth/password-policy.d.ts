import { ValidationOptions } from 'class-validator';
export declare const PASSWORD_MAX_BYTES = 72;
export declare const PASSWORD_MIN_LENGTH = 8;
export type PasswordRule = {
    id: string;
    label: string;
    test: (password: string) => boolean;
};
export declare const PASSWORD_RULES: PasswordRule[];
export declare function findPasswordIssues(password: string): string[];
export declare function findPasswordIssuesForUser(password: string, user: {
    email: string;
    nom: string;
}): string[];
export declare function MaxLengthBytes(max: number, validationOptions?: ValidationOptions): (object: object, propertyName: string) => void;
export declare function IsStrongPassword(validationOptions?: ValidationOptions): (object: object, propertyName: string) => void;
