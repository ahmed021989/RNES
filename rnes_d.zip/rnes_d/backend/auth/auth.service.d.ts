import { OnModuleInit } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { Repository } from 'typeorm';
import { User } from '../users/user.entity';
import { RegisterDto, LoginDto, ChangePasswordDto } from './dto';
export declare class AuthService implements OnModuleInit {
    private usersRepo;
    private jwt;
    constructor(usersRepo: Repository<User>, jwt: JwtService);
    onModuleInit(): Promise<void>;
    register(dto: RegisterDto): Promise<{
        nom: string;
        email: string;
        id: number;
        role: import("../users/user.entity").Role;
    }>;
    login(dto: LoginDto): Promise<{
        access_token: string;
        user: {
            id: number;
            nom: string;
            email: string;
            role: import("../users/user.entity").Role;
        };
    }>;
    changePassword(userId: number, dto: ChangePasswordDto): Promise<{
        message: string;
    }>;
}
