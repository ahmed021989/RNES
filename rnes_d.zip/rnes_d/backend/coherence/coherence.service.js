"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CoherenceService = void 0;
const common_1 = require("@nestjs/common");
const equipements_service_1 = require("../equipements/equipements.service");
let CoherenceService = class CoherenceService {
    equipements;
    constructor(equipements) {
        this.equipements = equipements;
    }
    async controler() {
        const equipements = await this.equipements.findAll();
        const usages = await this.equipements.findUsages();
        const compte = new Map();
        equipements.forEach((e) => compte.set(e.code, (compte.get(e.code) ?? 0) + 1));
        const doublons = [...compte.entries()].filter(([, n]) => n > 1).map(([c]) => c);
        const parPrefixe = new Map();
        for (const e of equipements) {
            const m = String(e.code ?? '').match(/^EQ-(.+)-(\d+)$/);
            if (!m)
                continue;
            const [, prefixe, num] = m;
            if (!parPrefixe.has(prefixe))
                parPrefixe.set(prefixe, new Set());
            parPrefixe.get(prefixe).add(Number(num));
        }
        const trous = [];
        for (const [prefixe, nums] of parPrefixe) {
            const max = Math.max(...nums);
            const manquants = [];
            for (let i = 1; i <= max; i++)
                if (!nums.has(i))
                    manquants.push(i);
            if (manquants.length)
                trous.push({ prefixe, numeros: manquants });
        }
        const usagesParEquip = new Map();
        usages.forEach((u) => {
            const l = usagesParEquip.get(u.equipement_code) ?? [];
            l.push(u);
            usagesParEquip.set(u.equipement_code, l);
        });
        const estActif = (s) => (s ?? '').trim().toLowerCase() === 'actif';
        const orphelins = equipements
            .filter((e) => estActif(e.statut) && (e.nature ?? '').toUpperCase() !== 'S')
            .filter((e) => (usagesParEquip.get(e.code) ?? []).length === 0);
        const isNA = (v) => {
            const s = (v ?? '').toUpperCase().trim();
            return !s || s === 'NA' || s === 'N/A';
        };
        const tousNA = equipements
            .filter((e) => estActif(e.statut))
            .filter((e) => {
            const us = usagesParEquip.get(e.code) ?? [];
            if (!us.length)
                return false;
            return us.every((u) => [u.nv1, u.nv2, u.nv3, u.nv4].every((v) => isNA(v)));
        });
        const lignes = [
            {
                code: '7.1.3',
                regle: 'Numérotation continue depuis 1, par préfixe',
                titre: trous.length
                    ? `${trous.length} préfixe(s) avec trou`
                    : 'Aucun trou parmi les numéros actifs',
                detail: trous.map((t) => `EQ-${t.prefixe} : n° ${t.numeros.join(', ')} (numéro jamais réattribué)`).join(' · '),
                statut: trous.length ? 'Anomalie' : 'Conforme',
            },
            {
                code: 'REG-1',
                regle: 'Codes dupliqués',
                titre: doublons.length ? `${doublons.length} doublon(s)` : 'Aucun doublon',
                detail: doublons.join(', '),
                statut: doublons.length ? 'Anomalie' : 'Conforme',
            },
            {
                code: 'REG-2',
                regle: 'Équipements T/SP sans spécialité reliée (orphelins)',
                titre: orphelins.length
                    ? `${orphelins.length} fiche(s). L'archivage reste une décision de l'administrateur.`
                    : 'Aucune fiche orpheline',
                detail: orphelins
                    .slice(0, 20)
                    .map((e) => `${e.code} ${e.designation ?? ''}`)
                    .join(' · '),
                statut: orphelins.length ? 'Anomalie' : 'Conforme',
            },
            {
                code: 'REG-3',
                regle: 'Quatre niveaux N/A pour tous les usages',
                titre: tousNA.length
                    ? `${tousNA.length} fiche(s) non retenues nulle part`
                    : 'Aucune fiche à niveaux vides',
                detail: tousNA.slice(0, 20).map((e) => `${e.code} ${e.designation ?? ''}`).join(' · '),
                statut: tousNA.length ? 'Anomalie' : 'Conforme',
            },
            {
                code: 'REG-4',
                regle: 'Confirmation avant archivage en cascade',
                titre: 'Appliquée à chaque archivage de spécialité ou de sous-référentiel.',
                detail: '',
                statut: 'Conforme',
            },
            {
                code: 'REG-5',
                regle: 'Désignations proches à la création',
                titre: "Détection (distance de Levenshtein ≤ 2) à la création d'une fiche.",
                detail: '',
                statut: 'Conforme',
            },
        ];
        const anomalies = lignes.filter((l) => l.statut === 'Anomalie').length;
        return { lignes, anomalies, total: lignes.length, verifieLe: new Date() };
    }
};
exports.CoherenceService = CoherenceService;
exports.CoherenceService = CoherenceService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [equipements_service_1.EquipementsService])
], CoherenceService);
//# sourceMappingURL=coherence.service.js.map