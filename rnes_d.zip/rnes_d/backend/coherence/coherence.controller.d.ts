import { CoherenceService } from './coherence.service';
export declare class CoherenceController {
    private service;
    constructor(service: CoherenceService);
    controler(): Promise<{
        lignes: {
            code: string;
            regle: string;
            titre: string;
            detail: string;
            equipement?: string;
            statut: "Conforme" | "Anomalie";
        }[];
        anomalies: number;
        total: number;
        verifieLe: Date;
    }>;
}
