"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CoherenceModule = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const coherence_controller_1 = require("./coherence.controller");
const coherence_service_1 = require("./coherence.service");
const equipements_service_1 = require("../equipements/equipements.service");
const equipement_entity_1 = require("../equipements/equipement.entity");
const specialite_entity_1 = require("../equipements/specialite.entity");
const sous_referentiel_entity_1 = require("../equipements/sous-referentiel.entity");
const usage_entity_1 = require("../equipements/usage.entity");
let CoherenceModule = class CoherenceModule {
};
exports.CoherenceModule = CoherenceModule;
exports.CoherenceModule = CoherenceModule = __decorate([
    (0, common_1.Module)({
        imports: [typeorm_1.TypeOrmModule.forFeature([equipement_entity_1.Equipement, specialite_entity_1.Specialite, sous_referentiel_entity_1.SousReferentiel, usage_entity_1.Usage])],
        controllers: [coherence_controller_1.CoherenceController],
        providers: [coherence_service_1.CoherenceService, equipements_service_1.EquipementsService],
    })
], CoherenceModule);
//# sourceMappingURL=coherence.module.js.map