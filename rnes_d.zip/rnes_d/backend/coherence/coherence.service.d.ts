import { EquipementsService } from '../equipements/equipements.service';
type Anomalie = {
    code: string;
    regle: string;
    titre: string;
    detail: string;
    equipement?: string;
    statut: 'Conforme' | 'Anomalie';
};
export declare class CoherenceService {
    private equipements;
    constructor(equipements: EquipementsService);
    controler(): Promise<{
        lignes: Anomalie[];
        anomalies: number;
        total: number;
        verifieLe: Date;
    }>;
}
export {};
