export declare class CoherenceModule {
}
