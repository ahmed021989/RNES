export declare class Usage {
    id: number;
    equipement_code: string;
    specialite_prefixe: string;
    nv1: string;
    nv2: string;
    nv3: string;
    nv4: string;
    indicateur_planification: string;
    prerequis: string;
    caracteristiques_indicatives: string;
    sous_famille_clinique: string;
    statut: string;
    supprime: boolean;
    date_suppression: Date;
}
