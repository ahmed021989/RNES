import { EquipementsService } from './equipements.service';
import { HistoriqueService } from '../historique/historique.service';
export declare class EquipementsController {
    private service;
    private historique;
    constructor(service: EquipementsService, historique: HistoriqueService);
    stats(): Promise<{
        totalEquipements: number;
        totalSpecialites: number;
        totalSousReferentiels: number;
        totalUsages: number;
        parCriticite: any[];
    }>;
    findSupprimes(search?: string): Promise<any[]>;
    restore(id: string, req: any): Promise<{
        restored: boolean;
        equipement: string;
        usagesRestaures: number;
    }>;
    findAll(search?: string): Promise<any[]>;
    findOne(id: string): Promise<import("./equipement.entity").Equipement>;
    create(dto: any, req: any): Promise<import("./equipement.entity").Equipement>;
    createWithUsage(dto: {
        equipement: any;
        usage: any;
    }, req: any): Promise<import("./equipement.entity").Equipement>;
    update(id: string, dto: any, req: any): Promise<import("./equipement.entity").Equipement>;
    remove(id: string, req: any): Promise<{
        deleted: boolean;
        equipement: string;
        usagesSupprimes: number;
    }>;
}
export declare class SpecialitesController {
    private service;
    private historique;
    constructor(service: EquipementsService, historique: HistoriqueService);
    findAll(archives?: string): Promise<any[]>;
    create(dto: any, req: any): Promise<import("./specialite.entity").Specialite>;
    update(id: string, dto: any, req: any): Promise<import("./specialite.entity").Specialite | null>;
    validate(id: string, req: any): Promise<import("./specialite.entity").Specialite | null>;
    devalidate(id: string, req: any): Promise<import("./specialite.entity").Specialite | null>;
    archive(id: string, req: any): Promise<import("./specialite.entity").Specialite | null>;
    unarchive(id: string, req: any): Promise<import("./specialite.entity").Specialite | null>;
}
export declare class SousReferentielsController {
    private service;
    private historique;
    constructor(service: EquipementsService, historique: HistoriqueService);
    findAll(archives?: string): Promise<any[]>;
    create(dto: any, req: any): Promise<import("./sous-referentiel.entity").SousReferentiel>;
    update(id: string, dto: any, req: any): Promise<import("./sous-referentiel.entity").SousReferentiel | null>;
    validate(id: string, req: any): Promise<import("./sous-referentiel.entity").SousReferentiel | null>;
    archive(id: string, req: any): Promise<import("./sous-referentiel.entity").SousReferentiel | null>;
    unarchive(id: string, req: any): Promise<import("./sous-referentiel.entity").SousReferentiel | null>;
}
export declare class UsagesController {
    private service;
    private historique;
    constructor(service: EquipementsService, historique: HistoriqueService);
    findAll(search?: string): Promise<import("./usage.entity").Usage[]>;
    findSupprimes(search?: string): Promise<any[]>;
    restore(id: string, req: any): Promise<{
        restored: boolean;
        id: number;
        equipement: string;
        specialite: string;
    }>;
    create(dto: any, req: any): Promise<import("./usage.entity").Usage>;
    update(id: string, dto: any, req: any): Promise<import("./usage.entity").Usage>;
    remove(id: string, req: any): Promise<{
        deleted: boolean;
        id: number;
    }>;
}
