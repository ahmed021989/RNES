export declare class SousReferentiel {
    id: number;
    code_prefixe: string;
    nom: string;
    ordre_affichage: number;
    statut: string;
    archive: boolean;
}
