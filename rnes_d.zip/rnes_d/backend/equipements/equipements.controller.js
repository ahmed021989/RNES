"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UsagesController = exports.SousReferentielsController = exports.SpecialitesController = exports.EquipementsController = void 0;
const common_1 = require("@nestjs/common");
const jwt_auth_guard_1 = require("../auth/jwt-auth.guard");
const public_decorator_1 = require("../auth/public.decorator");
const equipements_service_1 = require("./equipements.service");
const historique_service_1 = require("../historique/historique.service");
const roles_guard_1 = require("../auth/roles.guard");
const EQUIPEMENT_CHAMPS = [
    'designation',
    'nature',
    'proprietaire_prefixe',
    'type_objet',
    'famille_technique',
    'criticite_clinique',
    'mode_maintenance',
    'mode_mise_a_disposition',
    'portee',
    'justification',
    'statut',
];
function diff(before, dto, champs) {
    return champs
        .filter((c) => dto[c] !== undefined && String(dto[c] ?? '') !== String(before?.[c] ?? ''))
        .map((c) => `${c} : « ${before?.[c] ?? '—'} » → « ${dto[c] ?? '—'} »`);
}
let EquipementsController = class EquipementsController {
    service;
    historique;
    constructor(service, historique) {
        this.service = service;
        this.historique = historique;
    }
    stats() {
        return this.service.stats();
    }
    findSupprimes(search) {
        return this.service.findSupprimes(search);
    }
    async restore(id, req) {
        const res = await this.service.restore(+id);
        await this.historique.log('equipement', +id, 'restauration', `Récupération de l'équipement ${res.equipement}` +
            (res.usagesRestaures > 0 ? ` et de ${res.usagesRestaures} usage(s) rattaché(s)` : ' (aucun usage à récupérer)'), req.user?.email || 'inconnu');
        return res;
    }
    findAll(search) {
        return this.service.findAll(search);
    }
    findOne(id) {
        return this.service.findOneVisible(+id);
    }
    async create(dto, req) {
        const created = await this.service.create(dto);
        await this.historique.log('equipement', created.id, 'ajout', `Création de l'équipement « ${created.designation ?? ''} » (${created.code})`, req.user?.email || 'inconnu');
        return created;
    }
    async createWithUsage(dto, req) {
        const created = await this.service.createWithUsage(dto.equipement, dto.usage);
        const qui = req.user?.email || 'inconnu';
        await this.historique.log('equipement', created.id, 'ajout', `Création de l'équipement « ${created.designation ?? ''} » (${created.code})`, qui);
        if (dto.usage) {
            const usages = await this.service.findUsages(created.code);
            const u = usages[0];
            if (u) {
                await this.historique.log('usage', u.id, 'ajout', `Usage initial de ${created.code} pour ${u.specialite_prefixe} (${u.nv1} / ${u.nv2} / ${u.nv3} / ${u.nv4})`, qui);
            }
        }
        return created;
    }
    async update(id, dto, req) {
        const before = await this.service.findOne(+id);
        const updated = await this.service.update(+id, dto);
        const changes = diff(before, dto, EQUIPEMENT_CHAMPS);
        await this.historique.log('equipement', +id, 'modification', changes.length
            ? `Modification de ${updated.code} — ${changes.join(' ; ')}`
            : `Modification de ${updated.code} — aucun champ modifié`, req.user?.email || 'inconnu');
        return updated;
    }
    async remove(id, req) {
        const before = await this.service.findOne(+id);
        const res = await this.service.remove(+id);
        await this.historique.log('equipement', +id, 'archivage', `Suppression de l'équipement ${res.equipement} « ${before.designation ?? ''} »` +
            (res.usagesSupprimes > 0 ? ` et archivage de ${res.usagesSupprimes} usage(s) rattaché(s)` : ' (aucun usage rattaché)') +
            ' — récupérable depuis « Équipements supprimés »', req.user?.email || 'inconnu');
        return res;
    }
};
exports.EquipementsController = EquipementsController;
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Get)('stats'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], EquipementsController.prototype, "stats", null);
__decorate([
    (0, common_1.Get)('supprimes'),
    __param(0, (0, common_1.Query)('search')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], EquipementsController.prototype, "findSupprimes", null);
__decorate([
    (0, common_1.Post)(':id/restaurer'),
    (0, roles_guard_1.Roles)('admin'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], EquipementsController.prototype, "restore", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Get)(),
    __param(0, (0, common_1.Query)('search')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], EquipementsController.prototype, "findAll", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Get)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], EquipementsController.prototype, "findOne", null);
__decorate([
    (0, common_1.Post)(),
    (0, roles_guard_1.Roles)('admin'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], EquipementsController.prototype, "create", null);
__decorate([
    (0, common_1.Post)('with-usage'),
    (0, roles_guard_1.Roles)('admin'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], EquipementsController.prototype, "createWithUsage", null);
__decorate([
    (0, common_1.Put)(':id'),
    (0, roles_guard_1.Roles)('admin'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], EquipementsController.prototype, "update", null);
__decorate([
    (0, common_1.Delete)(':id'),
    (0, roles_guard_1.Roles)('admin'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], EquipementsController.prototype, "remove", null);
exports.EquipementsController = EquipementsController = __decorate([
    (0, common_1.Controller)('equipements'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, roles_guard_1.RolesGuard),
    __metadata("design:paramtypes", [equipements_service_1.EquipementsService, historique_service_1.HistoriqueService])
], EquipementsController);
let SpecialitesController = class SpecialitesController {
    service;
    historique;
    constructor(service, historique) {
        this.service = service;
        this.historique = historique;
    }
    findAll(archives) {
        return this.service.findSpecialites(archives === '1');
    }
    async create(dto, req) {
        const created = await this.service.createSpecialite(dto);
        await this.historique.log('specialite', created.id, 'ajout', `Création de la spécialité "${created.nom}" (${created.code_prefixe})`, req.user?.email || 'inconnu');
        return created;
    }
    async update(id, dto, req) {
        const updated = await this.service.updateSpecialite(+id, dto);
        await this.historique.log('specialite', +id, 'renommage', `Renommage de la spécialité en "${updated?.nom ?? ''}"`, req.user?.email || 'inconnu');
        return updated;
    }
    async validate(id, req) {
        const s = await this.service.validateSpecialite(+id);
        await this.historique.log('specialite', +id, 'validation', `Validation de la spécialité « ${s?.nom ?? ''} » (${s?.code_prefixe ?? ''}) — devient utilisable`, req.user?.email || 'inconnu');
        return s;
    }
    async devalidate(id, req) {
        const s = await this.service.devalidateSpecialite(+id);
        await this.historique.log('specialite', +id, 'devalidation', `Retrait de la validation de la spécialité « ${s?.nom ?? ''} » — retour en brouillon`, req.user?.email || 'inconnu');
        return s;
    }
    async archive(id, req) {
        const archived = await this.service.archiveSpecialite(+id);
        await this.historique.log('specialite', +id, 'archivage', `Archivage de la spécialité "${archived?.nom ?? ''}" — ses équipements quittent le référentiel sans être supprimés`, req.user?.email || 'inconnu');
        return archived;
    }
    async unarchive(id, req) {
        const restored = await this.service.unarchiveSpecialite(+id);
        await this.historique.log('specialite', +id, 'restauration', `Désarchivage de la spécialité "${restored?.nom ?? ''}" — ses équipements redeviennent visibles`, req.user?.email || 'inconnu');
        return restored;
    }
};
exports.SpecialitesController = SpecialitesController;
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Get)(),
    __param(0, (0, common_1.Query)('archives')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], SpecialitesController.prototype, "findAll", null);
__decorate([
    (0, common_1.Post)(),
    (0, roles_guard_1.Roles)('admin'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], SpecialitesController.prototype, "create", null);
__decorate([
    (0, common_1.Put)(':id'),
    (0, roles_guard_1.Roles)('admin'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], SpecialitesController.prototype, "update", null);
__decorate([
    (0, common_1.Put)(':id/valider'),
    (0, roles_guard_1.Roles)('admin'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], SpecialitesController.prototype, "validate", null);
__decorate([
    (0, common_1.Put)(':id/devalider'),
    (0, roles_guard_1.Roles)('admin'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], SpecialitesController.prototype, "devalidate", null);
__decorate([
    (0, common_1.Put)(':id/archiver'),
    (0, roles_guard_1.Roles)('admin'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], SpecialitesController.prototype, "archive", null);
__decorate([
    (0, common_1.Put)(':id/desarchiver'),
    (0, roles_guard_1.Roles)('admin'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], SpecialitesController.prototype, "unarchive", null);
exports.SpecialitesController = SpecialitesController = __decorate([
    (0, common_1.Controller)('specialites'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, roles_guard_1.RolesGuard),
    __metadata("design:paramtypes", [equipements_service_1.EquipementsService, historique_service_1.HistoriqueService])
], SpecialitesController);
let SousReferentielsController = class SousReferentielsController {
    service;
    historique;
    constructor(service, historique) {
        this.service = service;
        this.historique = historique;
    }
    findAll(archives) {
        return this.service.findSousReferentiels(archives === '1');
    }
    async create(dto, req) {
        const created = await this.service.createSousReferentiel(dto);
        await this.historique.log('sous_referentiel', created.id, 'ajout', `Création du sous-référentiel "${created.nom}" (${created.code_prefixe})`, req.user?.email || 'inconnu');
        return created;
    }
    async update(id, dto, req) {
        const updated = await this.service.updateSousReferentiel(+id, dto);
        await this.historique.log('sous_referentiel', +id, 'renommage', `Renommage du sous-référentiel en "${updated?.nom ?? ''}"`, req.user?.email || 'inconnu');
        return updated;
    }
    async validate(id, req) {
        const s = await this.service.validateSousReferentiel(+id);
        await this.historique.log('sous_referentiel', +id, 'validation', `Validation du sous-référentiel « ${s?.nom ?? ''} » (${s?.code_prefixe ?? ''}) — devient utilisable`, req.user?.email || 'inconnu');
        return s;
    }
    async archive(id, req) {
        const archived = await this.service.archiveSousReferentiel(+id);
        await this.historique.log('sous_referentiel', +id, 'archivage', `Archivage du sous-référentiel "${archived?.nom ?? ''}" — ses équipements transversaux quittent le référentiel sans être supprimés`, req.user?.email || 'inconnu');
        return archived;
    }
    async unarchive(id, req) {
        const restored = await this.service.unarchiveSousReferentiel(+id);
        await this.historique.log('sous_referentiel', +id, 'restauration', `Désarchivage du sous-référentiel "${restored?.nom ?? ''}" — ses équipements transversaux redeviennent visibles`, req.user?.email || 'inconnu');
        return restored;
    }
};
exports.SousReferentielsController = SousReferentielsController;
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Get)(),
    __param(0, (0, common_1.Query)('archives')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], SousReferentielsController.prototype, "findAll", null);
__decorate([
    (0, common_1.Post)(),
    (0, roles_guard_1.Roles)('admin'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], SousReferentielsController.prototype, "create", null);
__decorate([
    (0, common_1.Put)(':id'),
    (0, roles_guard_1.Roles)('admin'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], SousReferentielsController.prototype, "update", null);
__decorate([
    (0, common_1.Put)(':id/valider'),
    (0, roles_guard_1.Roles)('admin'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], SousReferentielsController.prototype, "validate", null);
__decorate([
    (0, common_1.Put)(':id/archiver'),
    (0, roles_guard_1.Roles)('admin'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], SousReferentielsController.prototype, "archive", null);
__decorate([
    (0, common_1.Put)(':id/desarchiver'),
    (0, roles_guard_1.Roles)('admin'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], SousReferentielsController.prototype, "unarchive", null);
exports.SousReferentielsController = SousReferentielsController = __decorate([
    (0, common_1.Controller)('sous-referentiels'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, roles_guard_1.RolesGuard),
    __metadata("design:paramtypes", [equipements_service_1.EquipementsService, historique_service_1.HistoriqueService])
], SousReferentielsController);
const USAGE_CHAMPS = [
    'specialite_prefixe',
    'nv1',
    'nv2',
    'nv3',
    'nv4',
    'indicateur_planification',
    'prerequis',
    'caracteristiques_indicatives',
    'sous_famille_clinique',
    'statut',
];
const nvResume = (u) => `NV1 ${u.nv1 ?? '—'} / NV2 ${u.nv2 ?? '—'} / NV3 ${u.nv3 ?? '—'} / NV4 ${u.nv4 ?? '—'}`;
let UsagesController = class UsagesController {
    service;
    historique;
    constructor(service, historique) {
        this.service = service;
        this.historique = historique;
    }
    findAll(search) {
        return this.service.findUsages(search);
    }
    findSupprimes(search) {
        return this.service.findUsagesSupprimes(search);
    }
    async restore(id, req) {
        const before = await this.service.getUsage(+id);
        const res = await this.service.restoreUsage(+id);
        await this.historique.log('usage', +id, 'restauration', `Récupération de l'usage ${res.equipement} / ${res.specialite} — ${nvResume(before)}`, req.user?.email || 'inconnu');
        return res;
    }
    async create(dto, req) {
        const created = await this.service.createUsage(dto);
        await this.historique.log('usage', created.id, 'ajout', `Ajout de l'usage ${created.equipement_code ?? '?'} / ${created.specialite_prefixe ?? '?'} — ${nvResume(created)}`, req.user?.email || 'inconnu');
        return created;
    }
    async update(id, dto, req) {
        const before = await this.service.getUsage(+id);
        const updated = (await this.service.updateUsage(+id, dto));
        const changes = diff(before, dto, USAGE_CHAMPS);
        await this.historique.log('usage', +id, 'modification', changes.length
            ? `Modification de l'usage ${updated.equipement_code} / ${updated.specialite_prefixe} — ${changes.join(' ; ')}`
            : `Modification de l'usage ${updated.equipement_code} / ${updated.specialite_prefixe} — aucun champ modifié`, req.user?.email || 'inconnu');
        return updated;
    }
    async remove(id, req) {
        const before = await this.service.getUsage(+id);
        await this.service.removeUsage(+id);
        await this.historique.log('usage', +id, 'archivage', `Retrait de l'usage ${before.equipement_code ?? '?'} / ${before.specialite_prefixe ?? '?'} — ${nvResume(before)}`, req.user?.email || 'inconnu');
        return { deleted: true, id: +id };
    }
};
exports.UsagesController = UsagesController;
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Get)(),
    __param(0, (0, common_1.Query)('search')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], UsagesController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)('supprimes'),
    __param(0, (0, common_1.Query)('search')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], UsagesController.prototype, "findSupprimes", null);
__decorate([
    (0, common_1.Post)(':id/restaurer'),
    (0, roles_guard_1.Roles)('admin'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], UsagesController.prototype, "restore", null);
__decorate([
    (0, common_1.Post)(),
    (0, roles_guard_1.Roles)('admin'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], UsagesController.prototype, "create", null);
__decorate([
    (0, common_1.Put)(':id'),
    (0, roles_guard_1.Roles)('admin'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], UsagesController.prototype, "update", null);
__decorate([
    (0, common_1.Delete)(':id'),
    (0, roles_guard_1.Roles)('admin'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], UsagesController.prototype, "remove", null);
exports.UsagesController = UsagesController = __decorate([
    (0, common_1.Controller)('usages'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, roles_guard_1.RolesGuard),
    __metadata("design:paramtypes", [equipements_service_1.EquipementsService, historique_service_1.HistoriqueService])
], UsagesController);
//# sourceMappingURL=equipements.controller.js.map