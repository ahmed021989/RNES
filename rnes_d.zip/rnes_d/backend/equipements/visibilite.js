"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.USAGE_VISIBLE = exports.SPECIALITES_VALIDES = void 0;
exports.referenceValidee = referenceValidee;
exports.estValidee = estValidee;
exports.porteurActif = porteurActif;
exports.onlyVisible = onlyVisible;
exports.onlyVisibleFrom = onlyVisibleFrom;
exports.onlyUsagesVisible = onlyUsagesVisible;
exports.visibleCodes = visibleCodes;
const STATUTS_VALIDES = `'active', 'actif'`;
function referenceValidee(alias) {
    return `(${alias}.statut IS NULL OR LOWER(TRIM(${alias}.statut)) IN (${STATUTS_VALIDES}))`;
}
function estValidee(statut) {
    return statut == null || ['active', 'actif'].includes(statut.trim().toLowerCase());
}
exports.SPECIALITES_VALIDES = `(SELECT code_prefixe FROM specialites WHERE archive = 0 AND ${referenceValidee('specialites')})`;
function porteurActif(alias) {
    return `(
    ${alias}.proprietaire_prefixe IN ${exports.SPECIALITES_VALIDES}
    OR ${alias}.proprietaire_prefixe IN (SELECT code_prefixe FROM sous_referentiels WHERE archive = 0 AND ${referenceValidee('sous_referentiels')})
    OR ${alias}.proprietaire_prefixe IS NULL
  )`;
}
const PORTEUR_ACTIF = porteurActif('e');
exports.USAGE_VISIBLE = `
  u.equipement_code IN (
    SELECT e.code FROM equipements e
    WHERE e.supprime = 0 AND ${PORTEUR_ACTIF}
  )
  AND u.specialite_prefixe IN ${exports.SPECIALITES_VALIDES}
`;
function onlyVisible(qb, alias) {
    return qb.andWhere(`${alias}.supprime = 0`).andWhere(porteurActif(alias));
}
function onlyVisibleFrom(qb, alias) {
    return qb.where(`${alias}.supprime = 0`).andWhere(porteurActif(alias));
}
function onlyUsagesVisible(qb) {
    return qb.andWhere('u.supprime = 0').andWhere(exports.USAGE_VISIBLE);
}
async function visibleCodes(qb, alias) {
    const rows = await qb
        .select(`${alias}.code`, 'code')
        .where(`${alias}.supprime = 0`)
        .andWhere(porteurActif(alias))
        .getRawMany();
    return rows.map((r) => r.code);
}
//# sourceMappingURL=visibilite.js.map