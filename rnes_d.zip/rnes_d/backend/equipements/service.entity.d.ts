export declare class Service {
    id: number;
    code: string;
    nom: string;
    ordre_affichage: number;
    statut: string;
}
