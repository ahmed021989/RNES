import { Repository } from 'typeorm';
import { Equipement } from './equipement.entity';
import { Specialite } from './specialite.entity';
import { SousReferentiel } from './sous-referentiel.entity';
import { Usage } from './usage.entity';
export declare class EquipementsService {
    private equipements;
    private specialites;
    private sousRefs;
    private usages;
    constructor(equipements: Repository<Equipement>, specialites: Repository<Specialite>, sousRefs: Repository<SousReferentiel>, usages: Repository<Usage>);
    private nextCode;
    private static proprietaireTypeDe;
    private normaliser;
    create(dto: any): Promise<Equipement>;
    createWithUsage(equipement: any, usage: any): Promise<Equipement>;
    findAll(search?: string): Promise<any[]>;
    findSupprimes(search?: string): Promise<any[]>;
    restore(id: number): Promise<{
        restored: boolean;
        equipement: string;
        usagesRestaures: number;
    }>;
    findOne(id: number): Promise<Equipement>;
    findOneVisible(id: number): Promise<Equipement>;
    update(id: number, dto: any): Promise<Equipement>;
    remove(id: number): Promise<{
        deleted: boolean;
        equipement: string;
        usagesSupprimes: number;
    }>;
    findSpecialites(includeArchives?: boolean): Promise<any[]>;
    createSpecialite(dto: any): Promise<Specialite>;
    validateSpecialite(id: number): Promise<Specialite | null>;
    devalidateSpecialite(id: number): Promise<Specialite | null>;
    updateSpecialite(id: number, dto: any): Promise<Specialite | null>;
    archiveSpecialite(id: number): Promise<Specialite | null>;
    unarchiveSpecialite(id: number): Promise<Specialite | null>;
    updateSousReferentiel(id: number, dto: any): Promise<SousReferentiel | null>;
    archiveSousReferentiel(id: number): Promise<SousReferentiel | null>;
    unarchiveSousReferentiel(id: number): Promise<SousReferentiel | null>;
    findSousReferentiels(includeArchives?: boolean): Promise<any[]>;
    createSousReferentiel(dto: any): Promise<SousReferentiel>;
    validateSousReferentiel(id: number): Promise<SousReferentiel | null>;
    findUsages(search?: string): Promise<Usage[]>;
    findUsagesSupprimes(search?: string): Promise<any[]>;
    restoreUsage(id: number): Promise<{
        restored: boolean;
        id: number;
        equipement: string;
        specialite: string;
    }>;
    private normalizeUsage;
    getUsage(id: number): Promise<Usage>;
    createUsage(dto: any): Promise<Usage>;
    updateUsage(id: number, dto: any): Promise<Usage | null>;
    removeUsage(id: number): Promise<{
        deleted: boolean;
        id: number;
    }>;
    stats(): Promise<{
        totalEquipements: number;
        totalSpecialites: number;
        totalSousReferentiels: number;
        totalUsages: number;
        parCriticite: any[];
    }>;
}
