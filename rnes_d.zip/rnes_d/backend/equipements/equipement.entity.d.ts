export declare class Equipement {
    id: number;
    code: string;
    designation: string;
    nature: string;
    proprietaire_type: string;
    proprietaire_prefixe: string;
    type_objet: string;
    famille_technique: string;
    criticite_clinique: string;
    mode_maintenance: string;
    mode_mise_a_disposition: string;
    portee: string;
    justification: string;
    statut: string;
    supprime: boolean;
    date_suppression: Date;
}
