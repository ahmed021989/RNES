"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.EquipementsModule = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const equipement_entity_1 = require("./equipement.entity");
const specialite_entity_1 = require("./specialite.entity");
const sous_referentiel_entity_1 = require("./sous-referentiel.entity");
const usage_entity_1 = require("./usage.entity");
const service_entity_1 = require("./service.entity");
const equipements_service_1 = require("./equipements.service");
const historique_module_1 = require("../historique/historique.module");
const equipements_controller_1 = require("./equipements.controller");
let EquipementsModule = class EquipementsModule {
};
exports.EquipementsModule = EquipementsModule;
exports.EquipementsModule = EquipementsModule = __decorate([
    (0, common_1.Module)({
        imports: [typeorm_1.TypeOrmModule.forFeature([equipement_entity_1.Equipement, specialite_entity_1.Specialite, sous_referentiel_entity_1.SousReferentiel, usage_entity_1.Usage, service_entity_1.Service]), historique_module_1.HistoriqueModule],
        providers: [equipements_service_1.EquipementsService],
        controllers: [equipements_controller_1.EquipementsController, equipements_controller_1.SpecialitesController, equipements_controller_1.SousReferentielsController, equipements_controller_1.UsagesController],
    })
], EquipementsModule);
//# sourceMappingURL=equipements.module.js.map