export declare class EquipementsModule {
}
