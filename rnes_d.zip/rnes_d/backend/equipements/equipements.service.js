"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var EquipementsService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.EquipementsService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const equipement_entity_1 = require("./equipement.entity");
const specialite_entity_1 = require("./specialite.entity");
const sous_referentiel_entity_1 = require("./sous-referentiel.entity");
const usage_entity_1 = require("./usage.entity");
const visibilite_1 = require("./visibilite");
let EquipementsService = EquipementsService_1 = class EquipementsService {
    equipements;
    specialites;
    sousRefs;
    usages;
    constructor(equipements, specialites, sousRefs, usages) {
        this.equipements = equipements;
        this.specialites = specialites;
        this.sousRefs = sousRefs;
        this.usages = usages;
    }
    async nextCode(prefixe) {
        const rows = await this.equipements.query("SELECT code FROM equipements WHERE code LIKE ? ORDER BY code DESC LIMIT 1", [`EQ-${prefixe}-%`]);
        const last = rows[0]?.code ?? '';
        const n = Number(last.split('-').pop() || 0) + 1;
        return `EQ-${prefixe}-${String(n).padStart(3, '0')}`;
    }
    static proprietaireTypeDe(nature) {
        return nature === 'T' ? 'SOUS_REFERENTIEL' : 'SPECIALITE';
    }
    normaliser(dto) {
        const out = { ...dto };
        if (out.nature)
            out.proprietaire_type = EquipementsService_1.proprietaireTypeDe(out.nature);
        if (out.statut === undefined || out.statut === null || out.statut === '')
            out.statut = 'Actif';
        return out;
    }
    async create(dto) {
        const base = this.normaliser(dto);
        const code = base.code || (await this.nextCode(base.proprietaire_prefixe || 'GEN'));
        return this.equipements.save(this.equipements.create({ ...base, code }));
    }
    async createWithUsage(equipement, usage) {
        const base = this.normaliser(equipement);
        const code = base.code || (await this.nextCode(base.proprietaire_prefixe || 'GEN'));
        const e = await this.equipements.save(this.equipements.create({ ...base, code }));
        if (usage) {
            const normalized = this.normalizeUsage(usage);
            await this.usages.save(this.usages.create({ ...normalized, equipement_code: e.code }));
        }
        return e;
    }
    findAll(search) {
        const qb = (0, visibilite_1.onlyVisible)(this.equipements
            .createQueryBuilder('e')
            .leftJoin('usages', 'u', 'u.equipement_code = e.code AND u.supprime = 0'), 'e')
            .select('e.id', 'id')
            .addSelect('e.code', 'code')
            .addSelect('e.designation', 'designation')
            .addSelect('e.nature', 'nature')
            .addSelect('e.proprietaire_type', 'proprietaire_type')
            .addSelect('e.proprietaire_prefixe', 'proprietaire_prefixe')
            .addSelect('e.type_objet', 'type_objet')
            .addSelect('e.famille_technique', 'famille_technique')
            .addSelect('e.criticite_clinique', 'criticite_clinique')
            .addSelect('e.mode_mise_a_disposition', 'mode_mise_a_disposition')
            .addSelect('e.portee', 'portee')
            .addSelect('e.statut', 'statut')
            .addSelect('COUNT(u.id)', 'nb_usages')
            .groupBy('e.id');
        if (search) {
            qb.andWhere('(e.code LIKE :q OR e.designation LIKE :q)', { q: `%${search}%` });
        }
        return qb.getRawMany().then((rows) => rows.map((r) => ({ ...r, nb_usages: Number(r.nb_usages) })));
    }
    findSupprimes(search) {
        const qb = this.equipements
            .createQueryBuilder('e')
            .leftJoin('usages', 'u', 'u.equipement_code = e.code AND u.supprime = 1')
            .where('e.supprime = 1')
            .select('e.id', 'id')
            .addSelect('e.code', 'code')
            .addSelect('e.designation', 'designation')
            .addSelect('e.nature', 'nature')
            .addSelect('e.proprietaire_prefixe', 'proprietaire_prefixe')
            .addSelect('e.criticite_clinique', 'criticite_clinique')
            .addSelect('e.statut', 'statut')
            .addSelect('e.date_suppression', 'date_suppression')
            .addSelect('COUNT(u.id)', 'nb_usages')
            .groupBy('e.id')
            .orderBy('e.date_suppression', 'DESC');
        if (search) {
            qb.andWhere('(e.code LIKE :q OR e.designation LIKE :q)', { q: `%${search}%` });
        }
        return qb.getRawMany().then((rows) => rows.map((r) => ({ ...r, nb_usages: Number(r.nb_usages) })));
    }
    async restore(id) {
        const e = await this.equipements.findOne({ where: { id } });
        if (!e)
            throw new common_1.NotFoundException('Equipement introuvable');
        if (!e.supprime)
            throw new common_1.BadRequestException("Cet équipement n'est pas supprimé");
        const usages = await this.usages.find({ where: { equipement_code: e.code, supprime: true } });
        await this.usages.manager.transaction(async (em) => {
            await em.update(equipement_entity_1.Equipement, id, { supprime: false, date_suppression: null });
            if (usages.length) {
                await em.update(usage_entity_1.Usage, usages.map((u) => u.id), { supprime: false, date_suppression: null });
            }
        });
        return { restored: true, equipement: e.code, usagesRestaures: usages.length };
    }
    async findOne(id) {
        const e = await this.equipements.findOne({ where: { id } });
        if (!e)
            throw new common_1.NotFoundException('Equipement introuvable');
        return e;
    }
    async findOneVisible(id) {
        const e = await this.findOne(id);
        if (e.supprime)
            throw new common_1.NotFoundException('Equipement introuvable');
        const porteuse = await (0, visibilite_1.onlyVisible)(this.equipements.createQueryBuilder('e'), 'e')
            .andWhere('e.id = :id', { id })
            .getCount();
        if (!porteuse)
            throw new common_1.NotFoundException('Equipement introuvable');
        return e;
    }
    async update(id, dto) {
        await this.findOne(id);
        await this.equipements.update(id, this.normaliser(dto));
        return this.findOne(id);
    }
    async remove(id) {
        const e = await this.findOne(id);
        const usages = await this.usages.find({ where: { equipement_code: e.code, supprime: false } });
        const quand = new Date();
        await this.usages.manager.transaction(async (em) => {
            if (usages.length) {
                await em.update(usage_entity_1.Usage, usages.map((u) => u.id), { supprime: true, date_suppression: quand });
            }
            await em.update(equipement_entity_1.Equipement, id, { supprime: true, date_suppression: quand });
        });
        return { deleted: true, equipement: e.code, usagesSupprimes: usages.length };
    }
    async findSpecialites(includeArchives = false) {
        const qb = this.specialites
            .createQueryBuilder('s')
            .leftJoin('equipements', 'e', 'e.proprietaire_prefixe = s.code_prefixe AND e.supprime = 0')
            .select('s.id', 'id')
            .addSelect('s.code_prefixe', 'code_prefixe')
            .addSelect('s.nom', 'nom')
            .addSelect('s.ordre_affichage', 'ordre_affichage')
            .addSelect('s.statut', 'statut')
            .addSelect('s.archive', 'archive')
            .addSelect("COUNT(CASE WHEN e.statut = 'Actif' THEN 1 END)", 'nb_equipements')
            .groupBy('s.id');
        if (!includeArchives)
            qb.andWhere('s.archive = 0');
        qb.orderBy('s.ordre_affichage', 'ASC').addOrderBy('s.code_prefixe', 'ASC');
        const rows = await qb.getRawMany();
        return rows.map((r) => ({ ...r, nb_equipements: Number(r.nb_equipements) }));
    }
    createSpecialite(dto) {
        return this.specialites.save(this.specialites.create({ statut: 'Brouillon', ...dto }));
    }
    async validateSpecialite(id) {
        const s = await this.specialites.findOne({ where: { id } });
        if (!s)
            throw new common_1.NotFoundException('Spécialité introuvable');
        if (s.statut === 'Active')
            throw new common_1.BadRequestException('Cette spécialité est déjà validée');
        await this.specialites.update(id, { statut: 'Active' });
        return this.specialites.findOne({ where: { id } });
    }
    async devalidateSpecialite(id) {
        const s = await this.specialites.findOne({ where: { id } });
        if (!s)
            throw new common_1.NotFoundException('Spécialité introuvable');
        await this.specialites.update(id, { statut: 'Brouillon' });
        return this.specialites.findOne({ where: { id } });
    }
    async updateSpecialite(id, dto) {
        const s = await this.specialites.findOne({ where: { id } });
        if (!s)
            throw new common_1.NotFoundException('Spécialité introuvable');
        await this.specialites.update(id, dto);
        return this.specialites.findOne({ where: { id } });
    }
    async archiveSpecialite(id) {
        return this.updateSpecialite(id, { archive: true });
    }
    async unarchiveSpecialite(id) {
        return this.updateSpecialite(id, { archive: false });
    }
    async updateSousReferentiel(id, dto) {
        const s = await this.sousRefs.findOne({ where: { id } });
        if (!s)
            throw new common_1.NotFoundException('Sous-référentiel introuvable');
        await this.sousRefs.update(id, dto);
        return this.sousRefs.findOne({ where: { id } });
    }
    async archiveSousReferentiel(id) {
        return this.updateSousReferentiel(id, { archive: true });
    }
    async unarchiveSousReferentiel(id) {
        return this.updateSousReferentiel(id, { archive: false });
    }
    async findSousReferentiels(includeArchives = false) {
        const qb = this.sousRefs
            .createQueryBuilder('s')
            .leftJoin('equipements', 'e', 'e.proprietaire_prefixe = s.code_prefixe AND e.supprime = 0')
            .select('s.id', 'id')
            .addSelect('s.code_prefixe', 'code_prefixe')
            .addSelect('s.nom', 'nom')
            .addSelect('s.ordre_affichage', 'ordre_affichage')
            .addSelect('s.statut', 'statut')
            .addSelect('s.archive', 'archive')
            .addSelect("COUNT(CASE WHEN e.statut = 'Actif' THEN 1 END)", 'nb_equipements')
            .groupBy('s.id');
        if (!includeArchives)
            qb.andWhere('s.archive = 0');
        qb.orderBy('s.ordre_affichage', 'ASC').addOrderBy('s.code_prefixe', 'ASC');
        const rows = await qb.getRawMany();
        return rows.map((r) => ({ ...r, nb_equipements: Number(r.nb_equipements) }));
    }
    createSousReferentiel(dto) {
        return this.sousRefs.save(this.sousRefs.create({ statut: 'Brouillon', ...dto }));
    }
    async validateSousReferentiel(id) {
        const s = await this.sousRefs.findOne({ where: { id } });
        if (!s)
            throw new common_1.NotFoundException('Sous-référentiel introuvable');
        if (s.statut === 'Actif')
            throw new common_1.BadRequestException('Ce sous-référentiel est déjà validé');
        await this.sousRefs.update(id, { statut: 'Actif' });
        return this.sousRefs.findOne({ where: { id } });
    }
    findUsages(search) {
        const qb = (0, visibilite_1.onlyUsagesVisible)(this.usages.createQueryBuilder('u'))
            .orderBy('u.equipement_code', 'ASC');
        if (search) {
            qb.andWhere('(u.equipement_code LIKE :q OR u.specialite_prefixe LIKE :q)', { q: `%${search}%` });
        }
        return qb.getMany();
    }
    findUsagesSupprimes(search) {
        const qb = this.usages
            .createQueryBuilder('u')
            .leftJoin(equipement_entity_1.Equipement, 'e', 'e.code = u.equipement_code')
            .where('u.supprime = 1')
            .select('u.id', 'id')
            .addSelect('u.equipement_code', 'equipement_code')
            .addSelect('u.specialite_prefixe', 'specialite_prefixe')
            .addSelect('u.nv1', 'nv1')
            .addSelect('u.nv2', 'nv2')
            .addSelect('u.nv3', 'nv3')
            .addSelect('u.nv4', 'nv4')
            .addSelect('u.indicateur_planification', 'indicateur_planification')
            .addSelect('u.prerequis', 'prerequis')
            .addSelect('u.date_suppression', 'date_suppression')
            .addSelect('e.designation', 'equipement_designation')
            .addSelect('e.nature', 'equipement_nature')
            .addSelect('e.supprime', 'equipement_supprime')
            .orderBy('u.date_suppression', 'DESC');
        if (search) {
            qb.andWhere('(u.equipement_code LIKE :q OR u.specialite_prefixe LIKE :q)', { q: `%${search}%` });
        }
        return qb.getRawMany();
    }
    async restoreUsage(id) {
        const u = await this.usages.findOne({ where: { id } });
        if (!u)
            throw new common_1.NotFoundException('Usage introuvable');
        if (!u.supprime)
            throw new common_1.BadRequestException("Cet usage n'est pas archivé");
        const equipement = await this.equipements.findOne({ where: { code: u.equipement_code } });
        if (!equipement) {
            throw new common_1.BadRequestException(`L'équipement ${u.equipement_code} n'existe plus : impossible de rattacher cet usage`);
        }
        if (equipement.supprime) {
            throw new common_1.BadRequestException(`L'équipement ${u.equipement_code} est supprimé. Récupérez d'abord l'équipement, puis cet usage.`);
        }
        const porteurArchive = equipement.proprietaire_prefixe
            ? equipement.nature === 'T'
                ? await this.sousRefs.findOne({ where: { code_prefixe: equipement.proprietaire_prefixe } })
                : await this.specialites.findOne({ where: { code_prefixe: equipement.proprietaire_prefixe } })
            : null;
        if (porteurArchive?.archive) {
            throw new common_1.BadRequestException(`Le ${porteurArchive.nom} qui porte ${u.equipement_code} est archivé. Désarchivez-le d'abord, puis récupérez cet usage.`);
        }
        await this.usages.update(id, { supprime: false, date_suppression: null });
        return { restored: true, id, equipement: u.equipement_code, specialite: u.specialite_prefixe };
    }
    normalizeUsage(dto) {
        const { specialite, specialite_prefixe, ...rest } = dto ?? {};
        return {
            ...rest,
            specialite_prefixe: specialite_prefixe ?? specialite ?? null,
        };
    }
    async getUsage(id) {
        const u = await this.usages.findOne({ where: { id } });
        if (!u)
            throw new common_1.NotFoundException('Usage introuvable');
        return u;
    }
    createUsage(dto) {
        return this.usages.save(this.usages.create({ statut: 'Actif', ...this.normalizeUsage(dto) }));
    }
    async updateUsage(id, dto) {
        const u = await this.usages.findOne({ where: { id } });
        if (!u)
            throw new common_1.NotFoundException('Usage introuvable');
        await this.usages.update(id, this.normalizeUsage(dto));
        return this.usages.findOne({ where: { id } });
    }
    async removeUsage(id) {
        const u = await this.usages.findOne({ where: { id } });
        if (!u)
            throw new common_1.NotFoundException('Usage introuvable');
        await this.usages.update(id, { supprime: true, date_suppression: new Date() });
        return { deleted: true, id };
    }
    async stats() {
        const visibles = await (0, visibilite_1.visibleCodes)(this.equipements.createQueryBuilder('e'), 'e');
        const specialitesActives = (await this.specialites
            .createQueryBuilder('s')
            .where('s.archive = 0')
            .andWhere((0, visibilite_1.referenceValidee)('s'))
            .select('s.code_prefixe', 'code_prefixe')
            .getRawMany()).map((s) => s.code_prefixe);
        const [totalSpecialites, totalSousReferentiels, totalUsages] = await Promise.all([
            this.specialites
                .createQueryBuilder('s')
                .where('s.archive = 0')
                .andWhere((0, visibilite_1.referenceValidee)('s'))
                .getCount(),
            this.sousRefs
                .createQueryBuilder('s')
                .where('s.archive = 0')
                .andWhere((0, visibilite_1.referenceValidee)('s'))
                .getCount(),
            visibles.length && specialitesActives.length
                ? this.usages.count({
                    where: {
                        supprime: false,
                        equipement_code: (0, typeorm_2.In)(visibles),
                        specialite_prefixe: (0, typeorm_2.In)(specialitesActives),
                    },
                })
                : 0,
        ]);
        const parCriticite = visibles.length
            ? await this.equipements
                .createQueryBuilder('e')
                .where('e.code IN (:...codes)', { codes: visibles })
                .select('e.criticite_clinique', 'criticite')
                .addSelect('COUNT(*)', 'total')
                .groupBy('e.criticite_clinique')
                .getRawMany()
            : [];
        return {
            totalEquipements: visibles.length,
            totalSpecialites,
            totalSousReferentiels,
            totalUsages,
            parCriticite,
        };
    }
};
exports.EquipementsService = EquipementsService;
exports.EquipementsService = EquipementsService = EquipementsService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(equipement_entity_1.Equipement)),
    __param(1, (0, typeorm_1.InjectRepository)(specialite_entity_1.Specialite)),
    __param(2, (0, typeorm_1.InjectRepository)(sous_referentiel_entity_1.SousReferentiel)),
    __param(3, (0, typeorm_1.InjectRepository)(usage_entity_1.Usage)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository])
], EquipementsService);
//# sourceMappingURL=equipements.service.js.map