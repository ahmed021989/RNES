import { Repository } from 'typeorm';
import { Evaluation } from './evaluation.entity';
export declare class EvaluationsService {
    private readonly evaluationRepository;
    constructor(evaluationRepository: Repository<Evaluation>);
    create(evaluation: Partial<Evaluation>): Promise<Evaluation>;
    findByEquipement(equipementCode: string): Promise<Evaluation[]>;
    findAll(): Promise<Evaluation[]>;
}
