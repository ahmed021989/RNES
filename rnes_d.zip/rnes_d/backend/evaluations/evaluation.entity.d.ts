export declare class Evaluation {
    id: number;
    equipementCode: string;
    evaluateur: string;
    date: Date;
    pertinence: number;
    efficacite: number;
    efficience: number;
    securite: number;
    accessibilite: number;
    maintenance: number;
    formation: number;
    scoreGlobal: number;
    commentaire: string;
    createdAt: Date;
}
