export declare class EvaluationsModule {
}
