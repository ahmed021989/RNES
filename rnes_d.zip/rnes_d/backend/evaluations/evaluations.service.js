"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.EvaluationsService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const evaluation_entity_1 = require("./evaluation.entity");
let EvaluationsService = class EvaluationsService {
    evaluationRepository;
    constructor(evaluationRepository) {
        this.evaluationRepository = evaluationRepository;
    }
    async create(evaluation) {
        const criteres = [
            evaluation.pertinence,
            evaluation.efficacite,
            evaluation.efficience,
            evaluation.securite,
            evaluation.accessibilite,
            evaluation.maintenance,
            evaluation.formation,
        ];
        const notes = criteres.map((v) => Number(v ?? 0));
        const scoreGlobal = notes.reduce((sum, val) => sum + val, 0) / notes.length;
        const newEvaluation = this.evaluationRepository.create({
            ...evaluation,
            scoreGlobal: Math.round(scoreGlobal * 100) / 100,
        });
        return this.evaluationRepository.save(newEvaluation);
    }
    async findByEquipement(equipementCode) {
        const evaluations = await this.evaluationRepository.find({
            where: { equipementCode },
            order: { date: 'DESC' },
        });
        if (evaluations.length === 0) {
            throw new common_1.NotFoundException(`Aucune évaluation trouvée pour l'équipement "${equipementCode}"`);
        }
        return evaluations;
    }
    async findAll() {
        return this.evaluationRepository.find({
            order: { date: 'DESC' },
        });
    }
};
exports.EvaluationsService = EvaluationsService;
exports.EvaluationsService = EvaluationsService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(evaluation_entity_1.Evaluation)),
    __metadata("design:paramtypes", [typeorm_2.Repository])
], EvaluationsService);
//# sourceMappingURL=evaluations.service.js.map