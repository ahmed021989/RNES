import { EvaluationsService } from './evaluations.service';
import { Evaluation } from './evaluation.entity';
export declare class EvaluationsController {
    private readonly evaluationsService;
    constructor(evaluationsService: EvaluationsService);
    create(evaluation: Partial<Evaluation>): Promise<Evaluation>;
    findByEquipement(equipementCode: string): Promise<Evaluation[]>;
    findAll(): Promise<Evaluation[]>;
}
