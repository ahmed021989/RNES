"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Evaluation = void 0;
const typeorm_1 = require("typeorm");
let Evaluation = class Evaluation {
    id;
    equipementCode;
    evaluateur;
    date;
    pertinence;
    efficacite;
    efficience;
    securite;
    accessibilite;
    maintenance;
    formation;
    scoreGlobal;
    commentaire;
    createdAt;
};
exports.Evaluation = Evaluation;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)(),
    __metadata("design:type", Number)
], Evaluation.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'equipement_code', type: 'varchar', length: 50 }),
    __metadata("design:type", String)
], Evaluation.prototype, "equipementCode", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'evaluateur', type: 'varchar', length: 255 }),
    __metadata("design:type", String)
], Evaluation.prototype, "evaluateur", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'date', type: 'datetime', default: () => 'CURRENT_TIMESTAMP' }),
    __metadata("design:type", Date)
], Evaluation.prototype, "date", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'pertinence', type: 'int' }),
    __metadata("design:type", Number)
], Evaluation.prototype, "pertinence", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'efficacite', type: 'int' }),
    __metadata("design:type", Number)
], Evaluation.prototype, "efficacite", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'efficience', type: 'int' }),
    __metadata("design:type", Number)
], Evaluation.prototype, "efficience", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'securite', type: 'int' }),
    __metadata("design:type", Number)
], Evaluation.prototype, "securite", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'accessibilite', type: 'int' }),
    __metadata("design:type", Number)
], Evaluation.prototype, "accessibilite", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'maintenance', type: 'int' }),
    __metadata("design:type", Number)
], Evaluation.prototype, "maintenance", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'formation', type: 'int' }),
    __metadata("design:type", Number)
], Evaluation.prototype, "formation", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'score_global', type: 'decimal', precision: 3, scale: 2 }),
    __metadata("design:type", Number)
], Evaluation.prototype, "scoreGlobal", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'commentaire', type: 'text', nullable: true }),
    __metadata("design:type", String)
], Evaluation.prototype, "commentaire", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ name: 'created_at' }),
    __metadata("design:type", Date)
], Evaluation.prototype, "createdAt", void 0);
exports.Evaluation = Evaluation = __decorate([
    (0, typeorm_1.Entity)('evaluations')
], Evaluation);
//# sourceMappingURL=evaluation.entity.js.map