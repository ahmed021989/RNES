export type Role = 'admin' | 'utilisateur';
export declare class User {
    id: number;
    nom: string;
    email: string;
    password: string;
    role: Role;
}
