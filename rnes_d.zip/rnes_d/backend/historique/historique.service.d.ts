import { Repository } from 'typeorm';
import { Historique } from './historique.entity';
export declare class HistoriqueService {
    private historique;
    constructor(historique: Repository<Historique>);
    log(entite: string, entite_id: number, action: string, details: string, utilisateur: string): Promise<Historique>;
    findAll(filters?: {
        entite?: string;
        action?: string;
        search?: string;
    }): Promise<Historique[]>;
}
