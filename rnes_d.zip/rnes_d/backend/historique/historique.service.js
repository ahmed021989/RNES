"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.HistoriqueService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const historique_entity_1 = require("./historique.entity");
let HistoriqueService = class HistoriqueService {
    historique;
    constructor(historique) {
        this.historique = historique;
    }
    async log(entite, entite_id, action, details, utilisateur) {
        return this.historique.save(this.historique.create({ entite, entite_id, action, details, utilisateur }));
    }
    findAll(filters) {
        const qb = this.historique
            .createQueryBuilder('h')
            .orderBy('h.date', 'DESC')
            .addOrderBy('h.id', 'DESC')
            .take(1000);
        if (filters?.entite)
            qb.andWhere('h.entite = :entite', { entite: filters.entite });
        if (filters?.action)
            qb.andWhere('h.action = :action', { action: filters.action });
        if (filters?.search) {
            qb.andWhere('(h.details LIKE :q OR h.utilisateur LIKE :q)', { q: `%${filters.search}%` });
        }
        return qb.getMany();
    }
};
exports.HistoriqueService = HistoriqueService;
exports.HistoriqueService = HistoriqueService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(historique_entity_1.Historique)),
    __metadata("design:paramtypes", [typeorm_2.Repository])
], HistoriqueService);
//# sourceMappingURL=historique.service.js.map