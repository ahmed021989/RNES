import { HistoriqueService } from './historique.service';
export declare class HistoriqueController {
    private service;
    constructor(service: HistoriqueService);
    findAll(entite?: string, action?: string, search?: string): Promise<import("./historique.entity").Historique[]>;
}
