export declare class HistoriqueModule {
}
