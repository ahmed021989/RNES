export declare class Historique {
    id: number;
    entite: string;
    entite_id: number;
    action: string;
    details: string;
    utilisateur: string;
    date: Date;
}
